import java.awt.*;
import javax.swing.*;

public class SudokuGUI extends JFrame{
    private JPanel sudPanel = new JPanel();

    public SudokuGUI(){
        setPreferredSize(new Dimension(400,380));

        sudPanel.setLayout(new GridLayout(3,3));

        sudPanel.setPreferredSize(new Dimension(400,380));

        
        for (int row = 0; row < 3; row++){

            for (int col = 0; col < 3; col++){
                sudBox = new JPanel(new GridLayout(3,3));

                for (int cell = 0; cell < 9; cell++) {
                    sudBox.add(new JButton());
                }

                sudPanel.add(sudBox);
                add(sudPanel);
                setVisible(true);

            }
        }

    }
}
