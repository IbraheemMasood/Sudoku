import javax.swing.*;
import java.awt.*;
import java.util.Arrays;

public class Main {
    public static void main(String[] args){
        //an array saving the numbers of the puzzle
        int[][] sudNumbers = new int[9][9];
        //an array saving whether a given spot has been solved
        boolean[][] sudIsSolved = new boolean[9][9];

        sudNumbers[0][0] = 5;
        sudNumbers[1][0] = 2;
        sudNumbers[2][0] = 7;
        sudNumbers[3][0] = 9;
        sudNumbers[4][0] = 4;
        sudNumbers[5][0] = 1;
        sudNumbers[6][0] = 8;
        sudNumbers[7][0] = 6;
        sudNumbers[8][0] = 3;
        sudNumbers[0][1] = 3;
        sudNumbers[1][1] = 8;
        sudNumbers[2][1] = 9;
        sudNumbers[3][1] = 2;
        sudNumbers[4][1] = 6;
        sudNumbers[5][1] = 7;
        sudNumbers[6][1] = 5;
        sudNumbers[7][1] = 1;
        sudNumbers[8][1] = 4;
        sudNumbers[0][2] = 6;
        sudNumbers[1][2] = 1;
        sudNumbers[2][2] = 4;
        sudNumbers[3][2] = 8;
        sudNumbers[4][2] = 5;
        sudNumbers[5][2] = 3;
        sudNumbers[6][2] = 2;
        sudNumbers[7][2] = 7;
        sudNumbers[8][2] = 9;
        sudNumbers[0][3] = 4;
        sudNumbers[1][3] = 3;
        sudNumbers[2][3] = 1;
        sudNumbers[3][3] = 5;
        sudNumbers[4][3] = 2;
        sudNumbers[5][3] = 9;
        sudNumbers[6][3] = 6;
        sudNumbers[7][3] = 8;
        sudNumbers[8][3] = 7;
        sudNumbers[0][4] = 9;
        sudNumbers[1][4] = 6;
        sudNumbers[2][4] = 2;
        sudNumbers[3][4] = 1;
        sudNumbers[4][4] = 7;
        sudNumbers[5][4] = 8;
        sudNumbers[6][4] = 4;
        sudNumbers[7][4] = 3;
        sudNumbers[8][4] = 5;
        sudNumbers[0][5] = 8;
        sudNumbers[1][5] = 7;
        sudNumbers[2][5] = 5;
        sudNumbers[3][5] = 6;
        sudNumbers[4][5] = 3;
        sudNumbers[5][5] = 4;
        sudNumbers[6][5] = 1;
        sudNumbers[7][5] = 9;
        sudNumbers[8][5] = 2;
        sudNumbers[0][6] = 7;
        sudNumbers[1][6] = 5;
        sudNumbers[2][6] = 8;
        sudNumbers[3][6] = 3;
        sudNumbers[4][6] = 1;
        sudNumbers[5][6] = 2;
        sudNumbers[6][6] = 9;
        sudNumbers[7][6] = 4;
        sudNumbers[8][6] = 6;
        sudNumbers[0][7] = 1;
        sudNumbers[1][7] = 4;
        sudNumbers[2][7] = 6;
        sudNumbers[3][7] = 7;
        sudNumbers[4][7] = 9;
        sudNumbers[5][7] = 5;
        sudNumbers[6][7] = 3;
        sudNumbers[7][7] = 2;
        sudNumbers[8][7] = 8;
        sudNumbers[0][8] = 2;
        sudNumbers[1][8] = 9;
        sudNumbers[2][8] = 3;
        sudNumbers[3][8] = 4;
        sudNumbers[4][8] = 8;
        sudNumbers[5][8] = 6;
        sudNumbers[6][8] = 7;
        sudNumbers[7][8] = 5;
        sudNumbers[8][8] = 1;

        sudIsSolved[0][0] = false;
        sudIsSolved[1][0] = false;
        sudIsSolved[2][0] = false;
        sudIsSolved[3][0] = true;
        sudIsSolved[4][0] = true;
        sudIsSolved[5][0] = true;
        sudIsSolved[6][0] = false;
        sudIsSolved[7][0] = false;
        sudIsSolved[8][0] = false;
        sudIsSolved[0][1] = true;
        sudIsSolved[1][1] = true;
        sudIsSolved[2][1] = false;
        sudIsSolved[3][1] = true;
        sudIsSolved[4][1] = true;
        sudIsSolved[5][1] = true;
        sudIsSolved[6][1] = false;
        sudIsSolved[7][1] = false;
        sudIsSolved[8][1] = true;
        sudIsSolved[0][2] = true;
        sudIsSolved[1][2] = false;
        sudIsSolved[2][2] = true;
        sudIsSolved[3][2] = false;
        sudIsSolved[4][2] = false;
        sudIsSolved[5][2] = false;
        sudIsSolved[6][2] = true;
        sudIsSolved[7][2] = false;
        sudIsSolved[8][2] = false;
        sudIsSolved[0][3] = false;
        sudIsSolved[1][3] = false;
        sudIsSolved[2][3] = true;
        sudIsSolved[3][3] = false;
        sudIsSolved[4][3] = true;
        sudIsSolved[5][3] = false;
        sudIsSolved[6][3] = false;
        sudIsSolved[7][3] = true;
        sudIsSolved[8][3] = false;
        sudIsSolved[0][4] = true;
        sudIsSolved[1][4] = false;
        sudIsSolved[2][4] = true;
        sudIsSolved[3][4] = false;
        sudIsSolved[4][4] = true;
        sudIsSolved[5][4] = true;
        sudIsSolved[6][4] = false;
        sudIsSolved[7][4] = true;
        sudIsSolved[8][4] = false;
        sudIsSolved[0][5] = true;
        sudIsSolved[1][5] = false;
        sudIsSolved[2][5] = false;
        sudIsSolved[3][5] = false;
        sudIsSolved[4][5] = true;
        sudIsSolved[5][5] = true;
        sudIsSolved[6][5] = true;
        sudIsSolved[7][5] = false;
        sudIsSolved[8][5] = false;
        sudIsSolved[0][6] = false;
        sudIsSolved[1][6] = true;
        sudIsSolved[2][6] = false;
        sudIsSolved[3][6] = true;
        sudIsSolved[4][6] = false;
        sudIsSolved[5][6] = true;
        sudIsSolved[6][6] = false;
        sudIsSolved[7][6] = true;
        sudIsSolved[8][6] = false;
        sudIsSolved[0][7] = false;
        sudIsSolved[1][7] = false;
        sudIsSolved[2][7] = true;
        sudIsSolved[3][7] = false;
        sudIsSolved[4][7] = true;
        sudIsSolved[5][7] = true;
        sudIsSolved[6][7] = false;
        sudIsSolved[7][7] = false;
        sudIsSolved[8][7] = true;
        sudIsSolved[0][8] = false;
        sudIsSolved[1][8] = false;
        sudIsSolved[2][8] = false;
        sudIsSolved[3][8] = false;
        sudIsSolved[4][8] = true;
        sudIsSolved[5][8] = true;
        sudIsSolved[6][8] = false;
        sudIsSolved[7][8] = true;
        sudIsSolved[8][8] = true;

        for (int i = 0; i <= sudNumbers.length -1; i++){
            for(int j = 0; j<= sudNumbers.length -1; j++){
                if (sudIsSolved[j][i]){
                    System.out.print(" " + sudNumbers[j][i] + " ");
                }
                else{
                    System.out.print("  ");
                }

            }
            System.out.println();

        }
        SudokuGUI gui = new SudokuGUI();
    }
}


