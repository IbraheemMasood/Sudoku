import javax.swing.*;
import java.awt.*;
//The sudoku buttons
public class Tile extends JButton {

    static final int SIZE = 70; //The size of the button in pixels
    static Color COLOR = Color.WHITE; //Editable button color
    static boolean VISIBLE = false; //Tracks whether a tile is visible or not
    static int VALUE = 0; //Tracks what number a tile holds
    int SHOWING = 0;//Shows the number inputted by the user
    boolean isShown = VISIBLE;
    Color textColor = Color.BLACK;

    public Tile() {
        //tile style
        setText(String.valueOf(VALUE));//Shows value on button
        setBorder(BorderFactory.createLineBorder(Color.black));
        setMargin(new Insets(0, 0, 0, 0));
        setBackground(COLOR);
        setForeground(textColor);
        setFont(new Font("Inter", Font.PLAIN, 25));



        if (!isShown){ //Sets button to blank if value isn't shown
            setText(" ");
        }


        addActionListener(new Handler());

    }
}

