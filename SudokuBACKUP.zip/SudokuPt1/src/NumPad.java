import javax.swing.*;
import java.awt.*;

import static java.awt.Color.*;

public class NumPad extends JButton {
    static int VALUE = 0;
    public NumPad() {
        super(String.valueOf(VALUE));
        setBorder(BorderFactory.createLineBorder(BLACK));
        setMargin(new Insets(0,0,0,0));
        setBackground(darkGray);
        setForeground(WHITE);
        setFont(new Font("Inter", Font.PLAIN, 40));

        int num = VALUE;
        addActionListener(new Handler());
    }
}
