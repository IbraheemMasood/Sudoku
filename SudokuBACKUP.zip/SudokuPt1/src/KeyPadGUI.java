import javax.swing.*;
import java.awt.*;

public class KeyPadGUI extends JFrame {
    public static NumPad[][] keyArray = new NumPad[9][9];
    public KeyPadGUI() {
        super("Numbers");
        JPanel keyPad = new JPanel();
        keyPad.setLayout(new GridLayout(3,3));
        keyPad.setPreferredSize(new Dimension(400,400));

        int numSet=1;
        for (int padRow = 0; padRow < 3; padRow++) {
            for (int padCol = 0; padCol < 3; padCol++) {
                NumPad.VALUE = numSet;
                NumPad number = new NumPad();
                keyPad.add(number);
                numSet++;
                keyArray[padRow][padCol] = number;

            }

            add(keyPad);
            pack();
            setVisible(true);
        }
    }
}
