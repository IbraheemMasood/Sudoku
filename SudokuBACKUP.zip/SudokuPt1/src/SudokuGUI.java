import java.awt.*;
import javax.swing.*;
import java.lang.Math;



public class SudokuGUI extends JFrame{
    public static Tile[][] buttonArray = new Tile[9][9];
    public SudokuGUI(int size){

        super("Sudoku by Ibraheem");

        JPanel sudBoard = new JPanel();
        sudBoard.setLayout(new GridLayout((int) Math.sqrt(size), (int) Math.sqrt(size)));
        sudBoard.setPreferredSize(new Dimension(Tile.SIZE*size, Tile.SIZE*size));

        for (int row = 0; row < (int)Math.sqrt(size); row++){

            for (int col = 0; col < (int)Math.sqrt(size); col++){

                JPanel sudBox = new JPanel(new GridLayout(3, 3));

                for (int innerRow = 0; innerRow < (int)Math.sqrt(size); innerRow++) {

                    if (col == 0 && row != 1 || col == 2 && row != 1 || col == 1 && row == 1){
                        Tile.COLOR = Color.GRAY;
                    }
                    else{
                        Tile.COLOR = Color.LIGHT_GRAY;
                    }
                    for (int innerCol = 0; innerCol < (int)Math.sqrt(size); innerCol++){
                        Tile.VALUE = Main.sudNumbers[col*3 + innerCol][row*3 + innerRow];
                        Tile.VISIBLE = Main.sudIsSolved[col*3 + innerCol][row*3 + innerRow];
                        Tile tile = new Tile();
                        sudBox.add(tile);
                        tile.SHOWING = Main.sudNumbers[col*3 + innerCol][row*3 + innerRow];
                        buttonArray[col*3+innerCol][row*3+innerRow] = tile;
                    }

                }

                sudBoard.add(sudBox);
                add(sudBoard);
                pack();
                setVisible(true);




            }

        }

    }
}

