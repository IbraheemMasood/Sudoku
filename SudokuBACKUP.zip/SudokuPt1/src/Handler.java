import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Handler implements ActionListener {
    @Override
    public void actionPerformed(ActionEvent e) {

        if (e.getSource() instanceof NumPad numpad){
            Main.CURRENTNUM = Integer.parseInt(numpad.getText());

        }

        else{
            Tile tile = (Tile) e.getSource(); //Checks what button was clicked
            if (!tile.isShown){
            tile.setText(String.valueOf(Main.CURRENTNUM));
            tile.SHOWING = Main.CURRENTNUM;
            tile.setForeground(new Color(7, 0, 120));
            }
            Main.isWon();

        }

    }
}
